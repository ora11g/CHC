﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using CHCIS.P.Contract.Message;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;

namespace CHCIS.UnitTests
{
    public class ItemServiceTests : TestBase
    {
        private const int INVOICE_DETAIL_ID = 24502;

        [Fact, Trait("ItemServiceTests", "项目接口测试")]
        public void GetInvoiceDtlById_Test_Method()
        {
            var invoiceDtlDto = GetInvoiceDtlById(INVOICE_DETAIL_ID);

            Assert.NotNull(invoiceDtlDto);
            Assert.Equal(INVOICE_DETAIL_ID, invoiceDtlDto.ID);
        }

        [Fact, Trait("ItemServiceTests", "项目接口测试")]
        public void UpdatePatientById_Test_Method()
        {
            var invoiceDtlDto = GetInvoiceDtlById(INVOICE_DETAIL_ID);

            Assert.NotNull(invoiceDtlDto);
            Assert.Equal(INVOICE_DETAIL_ID, invoiceDtlDto.ID);

            invoiceDtlDto.Memo = string.Concat("*** ", "MEMO", DateTime.Now.ToString("HHmmss"), " ***");

            HttpResponseMessage response = webApiHandler.HttpClient.PutAsJsonAsync(string.Format(@"api/items/{0}", invoiceDtlDto.ID), invoiceDtlDto).Result;

            response.EnsureSuccessStatusCode();

            invoiceDtlDto = response.Content.ReadAsAsync<InvoiceDtlDto>().Result;

            Assert.Equal(INVOICE_DETAIL_ID, invoiceDtlDto.ID);
        }

        [Fact, Trait("ItemServiceTests", "项目接口测试")]
        public void CreatePatient_Test_Method()
        {
            var invoiceDtlDto = GetInvoiceDtlById(INVOICE_DETAIL_ID);

            Assert.NotNull(invoiceDtlDto);
            Assert.Equal(INVOICE_DETAIL_ID, invoiceDtlDto.ID);

            invoiceDtlDto.ID = 0;
            invoiceDtlDto.Memo = string.Concat("*** ", "MEMO", DateTime.Now.ToString("HHmmss"), " ***");

            HttpResponseMessage response = webApiHandler.HttpClient.PostAsJsonAsync(@"api/items", invoiceDtlDto).Result;
            response.EnsureSuccessStatusCode();

            var newInvoiceDtlDto = response.Content.ReadAsAsync<PatientDto>().Result;

            Assert.NotNull(newInvoiceDtlDto);
            Assert.NotEqual(invoiceDtlDto.ID, newInvoiceDtlDto.ID);
        }

        [Fact, Trait("ItemServiceTests", "项目接口测试")]
        public void DeletePatientById_Test_Method()
        {
            var invoiceDtlDto = GetInvoiceDtlById(INVOICE_DETAIL_ID);

            Assert.NotNull(invoiceDtlDto);
            Assert.Equal(INVOICE_DETAIL_ID, invoiceDtlDto.ID);

            invoiceDtlDto.ID = 0;
            invoiceDtlDto.Memo = string.Concat("*** ", "MEMO", DateTime.Now.ToString("HHmmss"), " ***");

            HttpResponseMessage response = webApiHandler.HttpClient.PostAsJsonAsync(@"api/items", invoiceDtlDto).Result;
            response.EnsureSuccessStatusCode();

            var newInvoiceDtlDto = response.Content.ReadAsAsync<PatientDto>().Result;

            Assert.NotNull(newInvoiceDtlDto);
            Assert.NotEqual(invoiceDtlDto.ID, newInvoiceDtlDto.ID);


            response = webApiHandler.HttpClient.DeleteAsync(string.Format(@"api/items/{0}", newInvoiceDtlDto.ID)).Result;

            Assert.True(response.StatusCode == HttpStatusCode.OK);
        }

        public InvoiceDtlDto GetInvoiceDtlById(int invoiceDtlId)
        {
            string path = string.Format("api/items/{0}", invoiceDtlId);

            HttpResponseMessage response = webApiHandler.HttpClient.GetAsync(path).Result;

            if (response.IsSuccessStatusCode)
            {
                return response.Content.ReadAsAsync<InvoiceDtlDto>().Result;
            }
            else
            {
                throw new NullReferenceException(string.Format("No invoice details found with invoiceDtlId '{0}'.", invoiceDtlId));
            }
        }
    }
}
