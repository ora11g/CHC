﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using Xx.His.Client;
using Xx.His.Client.Support;

namespace CHCIS.UnitTests
{
    public class TestBase
    {
        protected static readonly WebApiHandler webApiHandler = new WebApiHandler();

        static TestBase()
        {
        }        
    }
}
