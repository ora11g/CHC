﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using CHCIS.P.Contract.Message;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using Xx.His.Client;
using Xx.His.Client.Support;

namespace CHCIS.UnitTests
{
    public class PatientApiTests : TestBase
    {
        private const int PATIENT_ID = 12;        

        [Fact, Trait("PatientApiTests", "患者接口测试")]
        public void GetPatientById_Test_Method()
        {
            var patientDto = GetPatientById(PATIENT_ID);

            Assert.NotNull(patientDto);
            Assert.Equal(PATIENT_ID, patientDto.ID);
        }

        [Fact, Trait("PatientApiTests", "患者接口测试")]
        public void UpdatePatientById_Test_Method()
        {
            var patientDto = GetPatientById(PATIENT_ID);

            Assert.NotNull(patientDto);
            Assert.Equal(PATIENT_ID, patientDto.ID);

            patientDto.Name = string.Concat("*** ", "TEST NAME ", DateTime.Now.ToString("HHmmss"), " ***");

            HttpResponseMessage response = webApiHandler.HttpClient.PutAsJsonAsync(string.Format(@"api/patients/{0}", patientDto.ID), patientDto).Result;
            
            response.EnsureSuccessStatusCode();

            patientDto = response.Content.ReadAsAsync<PatientDto>().Result;

            Assert.Equal(PATIENT_ID, patientDto.ID);
        }

        [Fact, Trait("PatientApiTests", "患者接口测试")]
        public void CreatePatient_Test_Method()
        {            
            var patientDto = GetPatientById(PATIENT_ID);

            Assert.NotNull(patientDto);
            Assert.Equal(PATIENT_ID, patientDto.ID);

            patientDto.ID = 0;
            patientDto.Name = string.Concat("*** ", "TEST NAME ", DateTime.Now.ToString("HHmmss"), " ***");

            HttpResponseMessage response = webApiHandler.HttpClient.PostAsJsonAsync(@"api/patients", patientDto).Result;
            response.EnsureSuccessStatusCode();

            var newPatientDto = response.Content.ReadAsAsync<PatientDto>().Result;

            Assert.NotNull(newPatientDto);
            Assert.NotEqual(patientDto.ID, newPatientDto.ID);
        }

        [Fact, Trait("PatientApiTests", "患者接口测试")]
        public void DeletePatientById_Test_Method()
        {
            var patientDto = GetPatientById(PATIENT_ID);

            Assert.NotNull(patientDto);
            Assert.Equal(PATIENT_ID, patientDto.ID);

            patientDto.ID = 0;
            patientDto.Name = string.Concat("*** ", "TEST NAME ", DateTime.Now.ToString("HHmmss"), " ***");

            HttpResponseMessage response = webApiHandler.HttpClient.PostAsJsonAsync(@"api/patients", patientDto).Result;
            response.EnsureSuccessStatusCode();

            var newPatientDto = response.Content.ReadAsAsync<PatientDto>().Result;

            Assert.NotNull(newPatientDto);
            Assert.NotEqual(patientDto.ID, newPatientDto.ID);


            response = webApiHandler.HttpClient.DeleteAsync(string.Format(@"api/patients/{0}", newPatientDto.ID)).Result;

            Assert.True(response.StatusCode == HttpStatusCode.OK);
        }

        public PatientDto GetPatientById(int patientId)
        {
            string path = string.Format("api/patients/{0}", patientId);

            HttpResponseMessage response = webApiHandler.HttpClient.GetAsync(path).Result;
            
            if (response.IsSuccessStatusCode)
            {
                return response.Content.ReadAsAsync<PatientDto>().Result;
            }
            else
            {
                throw new NullReferenceException(string.Format("No patient found with patientId '{0}'.", patientId));
            }
        }

    }    
}
